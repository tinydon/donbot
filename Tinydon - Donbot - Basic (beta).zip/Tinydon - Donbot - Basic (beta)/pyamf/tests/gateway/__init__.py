# Copyright (c) The PyAMF Project.
# See LICENSE for details.

"""
Unit tests for Remoting gateways.

@since: 0.1.0
"""
